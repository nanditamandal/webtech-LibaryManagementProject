<?php
	require "db.php";
	$id=$_GET['id'];
			$conn = DBconnection();
			$sql ="INSERT INTO product (name ,quantity, price, type, picture,notwork, working) SELECT name ,quantity, price, type, picture,notwork, working FROM temp WHERE id='$id'";
			 $sql2="DELETE FROM temp WHERE id='$id'";

			$result = mysqli_query($conn, $sql);
			$result2=mysqli_query($conn, $sql2);
			
			if($result && $result2){
			header("location: adminhomepage.php");
		}else{
			header("location: confirmpermission.php?error=true");
		}
			mysqli_close($conn);
			//header('location:admin.php');
	
?>