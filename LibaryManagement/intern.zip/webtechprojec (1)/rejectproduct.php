<?php
// including the database connection file
  include_once("db.php");
$id = $_GET['id'];
$conn = DBconnection();
 
$result = mysqli_query($conn, "SELECT * FROM temp WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $name = $res['name'];
	$price = $res['price'];
	$quantity = $res['quantity'];
	$type = $res['type'];
    $image=$res['picture'];
   
}
 


?>
<?php


?>
<html>
<head>    
    <title>Edit Data</title>
</head>
 
<body>
    <a href="adminhomepage.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="POST" action="pleasemodify.php" enctype="multipart/form-data">
        <table border="0">
            <tr> 
                <td>Name</td>
                <td><?php echo $name;?></td>
            </tr>
			<tr> 
                <td>price</td>
                <td><?php echo $price;?></td>
            </tr>
			<tr> 
                <td>type</td>
                <td><?php echo $type;?></td>
            </tr>
			<tr> 
                <td>quantity</td>
                <td><?php echo $quantity;?></td>
            </tr>
			<tr>
				
                <td>picture</td>

                
                    
				<td>
                    <?php echo"<img src='image/$image' width='500' height='250'>"; ?>
                    
                    
                </td>

            </tr>
            <tr> 
                <td>comment</td>
                <td><input type="text" name="confirm" ></td>
            </tr>
            
            <tr>
               <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>