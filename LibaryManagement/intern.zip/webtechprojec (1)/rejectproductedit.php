<?php
// including the database connection file
  include_once("db.php");
$id = $_GET['id'];
$conn = DBconnection();
 
$result = mysqli_query($conn, "SELECT * FROM temp WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $name = $res['name'];
	$price = $res['price'];
	$quantity = $res['quantity'];
	$type = $res['type'];
    $image=$res['picture'];
   
}
 
if(isset($_POST['update']))
{    
  
    $id = $_POST['id'];
    $name=$_POST['name'];
	$price=$_POST['price'];
	$quantity=$_POST['quantity'];
	$type=$_POST['type'];
    $confirm=$_POST['confirm'];
	$image = $_FILES['image']['name'];
	$target = "image/".basename($image);
	$conn = DBconnection();
            
     
        $result = mysqli_query($conn, "UPDATE temp SET name='$name',price='$price',quantity='$quantity',type='$type',confirm='$confirm',picture='$image' WHERE id= $id");

		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {

  		$msg = "Image uploaded successfully";
		}
        else{
  		$msg = "Failed to upload image";
  	     }
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: view_users.php");

        if($result)
    {
          header("Location: salesmanhomepage.php");
    }
    else{
        header("Location: rejectproductedit.php?error=true");
        
        
    }
        mysqli_close($conn);
    
}

?>
<?php


?>
<html>
<head>    
    <title>Edit Data</title>
</head>
 
<body>
    <a href="salesmanhomepage.php">Home</a>
    <br/><br/>
    
    <form name="form1" method="post" action="rejectproductedit.php" enctype="multipart/form-data">
        <table border="0">
            <tr> 
                <td>Name</td>
                <td><input type="text" name="name" value="<?php echo $name;?>"></td>
            </tr>
			<tr> 
                <td>price</td>
                <td><input type="text" name="price" value="<?php echo $price;?>"></td>
            </tr>
			<tr> 
                <td>type</td>
                <td><input type="text" name="type" value="<?php echo $type;?>"></td>
            </tr>
			<tr> 
                <td>quantity</td>
                <td><input type="text" name="quantity" value="<?php echo $quantity;?>"></td>
            </tr>
             <tr> 
                
                <td><input type="hidden" name="confirm" value=""></td>
            </tr>

           
			<tr>
				
                <td>picture</td>

                
                    
				<td>
                    <?php echo"<img src='image/$image' width='500' height='250'>"; ?>
                    
                    <input type="file" name="image" value="">
                </td>
                
               

               
			</tr>
            
            <tr>
               <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>