<?php
error_reporting(0);
  $db = mysqli_connect("localhost", "root", "", "webtech");
	$msg = "";


  
  if (isset($_POST['update'])) {

	  $confirm=$_POST['confirm'];
	  $id = $_POST['id'];
	  
		echo $confirm;
		echo $id;
		 if(empty($confirm)){
            $eprice .= "please enter comment"; /////$error=$msg
		  } 
		else{
			$sql = "UPDATE temp SET confirm='$confirm' WHERE id= $id";
  
			$result = mysqli_query($db, $sql);
			if($result){

				header("location: adminhomepage.php");
			}
			else{
				header("location: pleasemodify.php?error=true");

			}
			}
		}
  

  	
  
 // $result = mysqli_query($db, "SELECT * FROM image");
?>
