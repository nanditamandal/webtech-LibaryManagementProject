<?php
	echo"
	<br></br>
<br></br>
<br></br>
	<div style='text-align:center'>
		<h style='color:blue;'>copyright@aiub.com</h>
	</div>";

?>